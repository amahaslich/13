<?
$mysqli = new mysqli("localhost", "root", "", "mydb");
$mysqli -> set_charset("cp125");

$title=$_POST['title'];
$author=$_POST['author'];
$pages=$_POST['pages'];
$publisher=$_POST['publisher'];

if (($title=="")||($author=="")||($pages=="")||($publisher=="")){
	echo('Ошибка. Не все поля заполнены');
	echo "<form action='index.html'>";
			echo "<input type='submit' value='Меню'>";
		echo "</form>";
}else{
	$z = "insert into `books` (`title`, `author`, `pages`, `publisher`) 
values ('$title', '$author', '$pages', '$publisher')";

$result = $mysqli->query($z);
echo ('Книга добавлена');
echo "<form action='index.html'>";
			echo "<input type='submit' value='Меню'>";
		echo "</form>";
}
?>