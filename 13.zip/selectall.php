<?
$mysqli = new mysqli("localhost", "root", "", "mydb");
$mysqli -> set_charset("cp125");


$z = "SELECT * FROM `books`";
$result = $mysqli->query($z);
echo "<table border ='1'>";
echo '<tr><th>Id</th><th>Название</th><th>Автор</th><th>Количество страниц</th><th>Издательство</th>';
while ($book = $result->fetch_assoc()){
echo "<tr>";
echo "<td>".$book["id"].'</td><td>'.$book["title"].'</td><td>'.$book["author"]."</td><td>".$book["pages"]."</td><td>".$book["publisher"]."</td>";
echo "</tr>";
}
echo "<form action='index.html'>";
		echo "<input type='submit' value='Меню'>";
	echo "</form>";
?>